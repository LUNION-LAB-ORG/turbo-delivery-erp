import Content from './content';

export default async function Page() {
    return <Content />;
}
