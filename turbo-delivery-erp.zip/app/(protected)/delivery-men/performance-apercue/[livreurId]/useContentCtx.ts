// import { PerformanceCreneauId } from "@/types/performance-creneauId"
// import { useEffect, useState } from "react"

// export default function useContentCtx({initialData}:{initialData:PerformanceCreneauId}){

// const [data,setData] = useState<PerformanceCreneauId>(initialData)

// useEffect(()=>{
//     const newData= initialData.creneaux.slice(0, 3);
//     setData(newData)
// },[])

//     return {
//         data
//     }
// }