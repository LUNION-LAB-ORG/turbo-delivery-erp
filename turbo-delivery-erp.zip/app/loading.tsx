import Loading from '@/components/layouts/loading';
import React from 'react';

const loading = () => {
    return <Loading />;
};

export default loading;
